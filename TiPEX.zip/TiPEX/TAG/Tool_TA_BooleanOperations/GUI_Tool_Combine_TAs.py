####################################################################
####################################################################
from Tkinter import *
import Tkinter
import tkMessageBox
import os
from tkFileDialog import askopenfilename

import pyuppaal
import UnionTA
import IntersectionTA
####################################################################
####################################################################

###Create the GUI elements and launch the GUI####### 
def createGUI():
    window = Tkinter.Tk()
    window.title("Combine TAs")
    window.minsize(300,170)
    window.geometry("400x170")
    
    # variable to store the path of the selected file##
    uppaalModel = StringVar()
    uppaalModel.set("No file chosen!!")
    
    # To display title of the GUI##
    title = Label(window, fg="blue",font=6, text= "Combine TAs using Boolean operations")
    title.place (x=50, y=10) 

    ## Other labels on the GUI##
    L1 = Label(window,  text="Uppaal Model")
    L1.place (x=30, y=50) 
    L2 = Label(window, text="Operation")
    L2.place (x=30, y=85) 

    ## Dropdown to select operation##
    opr = StringVar(window)
    opr.set("intersection") # default value
    p = OptionMenu(window, opr, "union", "intersection")
    p.place (x=150, y=85) 
    ##################################
    ##################################

    ##Method invoked to choose a file when the button "chooseFile" is clicked ### 
    def openFile():
        Tk().withdraw() 
        filename = askopenfilename() 
        print(filename)
        uppaalModel.set(filename)
        ###################################################

    ##Method invoked when the button combine TAs is clicked##
    def performOperation():
        operation = str(opr.get())
        extension = os.path.splitext(uppaalModel.get())[-1].lower()
        
        if (uppaalModel.get()=="No file chosen!!"):
            tkMessageBox.showinfo( "status" , "Please select a valid UPPAAL model (.xml) containing the input TAs."   )
        
        
        if (extension <>'.xml'):
            tkMessageBox.showinfo( "status" , "Selected file is not a .xml. Please select a valid UPPAAL model (.xml) containing the input TAs."   )
                
        else:
            ##Parse the input Uppaal model##
            Parsed_NTA_Pyuppaal = pyuppaal.NTA.from_xml(open(uppaalModel.get()))

            ###template[0]  and template[1]  of the Uppaal model contain the input TAs.
            PA1 = Parsed_NTA_Pyuppaal.templates[0]
            PA2 = Parsed_NTA_Pyuppaal.templates[1]
   
            ###Combining the TAs.###
            if operation=="union":
                resultTA = UnionTA.Union(PA1,PA2) 
    
            elif operation=="intersection":
                resultTA= IntersectionTA.Intersection(PA1,PA2)
    
            else:
                print "Operation undefined!!"
                exit
         
            ###Adding another template to the Uppaal model (containing the TA obtained as a result of the operation performed).###
            Parsed_NTA_Pyuppaal.add_template(resultTA)
    
            ####File operations (writing the updated model to file).### 
            f = open(uppaalModel.get(), "r+")
            f.writelines(pyuppaal.NTA.to_xml(Parsed_NTA_Pyuppaal))
            f.close()
            print "Operation " + operation + " is performed, and the resulting TA is written (added as another template) to the UPPAAL model file!!" 
            tkMessageBox.showinfo( "status" , "Operation " + operation + " is performed, and the resulting TA is written (added as another template) to the UPPAAL model file!!" )
        ####################################################
        ####################################################
    #Buttons on the GUI
    B1 = Tkinter.Button(window, text ="SelectFile", command = openFile)
    B1.place (x=150, y=48) 
    #
    B2 = Tkinter.Button(window, text ="     CombineTAs     ", fg = "light blue",
         bg = "dark blue", command = performOperation)
    B2.place (x=110, y=130)
    ######################
    window.mainloop()
    
#########################################################################################################################
#########################################################################################################################


