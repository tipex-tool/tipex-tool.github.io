##########################################
import pyuppaal
import os.path
import sys
###########################################
import UnionTA
import IntersectionTA
###########################################
 
# This is the main test method, to test the boolean operations on TAs##############
# It takes the following as input: 
## Input "uppaalModel": Uppaal model as .xml. The Uppaal model should contain 2 templates. ####
## The  two templates contain TAs which we want to combine using operations such as Union and Intersection. ## 
## Input "operation": The operation one wants to perform. The should be one of the following {"union", "intersection"}##  
####################################################################################
def testBooleanOperationsTAs(uppaalModel, operation):
    # Current working directory
    projdir = os.path.normpath(os.path.join(os.path.dirname(__file__), '..'))
    # system path
    sys.path = [projdir] + sys.path
    Uppaal_Model = os.path.join(os.path.dirname(__file__), uppaalModel)
   
    print(Uppaal_Model)
    ##Parse the input Uppaal model##
    Parsed_NTA_Pyuppaal = pyuppaal.NTA.from_xml(open(Uppaal_Model))

    ###template[0]  and template[1]  of the Uppaal model contain the input TAs.
    PA1 = Parsed_NTA_Pyuppaal.templates[0]
    PA2 = Parsed_NTA_Pyuppaal.templates[1]
   
    ###Combining the TAs.###
    if operation=="union":
        resultTA = UnionTA.Union(PA1,PA2) 
    
    elif operation=="intersection":
        resultTA= IntersectionTA.Intersection(PA1,PA2)
    
    else:
        print "Operation undefined!!"
        exit
         
    ###Adding another template to the Uppaal model (containing the TA obtained as a result of the operation performed).###
    Parsed_NTA_Pyuppaal.add_template(resultTA)
    
    ####File operations (writing the updated model to file).### 
    f = open(Uppaal_Model, "r+")
    f.writelines(pyuppaal.NTA.to_xml(Parsed_NTA_Pyuppaal))
    f.close()
    print "Operation " + operation + " is performed, and the resulting TA is written (added as another template) to the UPPAAL model file!!"  

########################################    
##Invoking the tester method.###
## Input: Uppaal model as .xml. The Uppaal model should contain 2 templates. ####
## The  two templates contain TAs which we want to combine using operations such as Union and Intersection. ##
#testBooleanOperationsTAs('Example_Safety.xml', "union")
########################################    
