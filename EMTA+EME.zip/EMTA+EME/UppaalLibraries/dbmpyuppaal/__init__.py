from dbmpyuppaal import parse_xml, parse_clocks, ClockBounds, NTAState
