######################################################
######################################################
#
About:
--------------
This folder contains the following modules implemented in Python:
1. checkPropertyClass.py:  The module contains the "checkClass" function which takes a TA as input (an UPPAAL model stored as .xml), and checks(answers) whether the TA defines a Safety, or a Co-safety property.
 
2. tester.py:
 tester.py module contains a function "test", demonstrating usage of the above function.
 The "checkClass" functionality is tested with some TAs (available in the "ExampleTAs" folder) invoking the test function with each of these TAs as input. 

 NOTE: Note that in the UPPAAL model defining the input TAs, non-accepting locations should be named as "Bad". 
 
3. GUI_Tool_TA_ClassIdentifier.py:
This module implements the GUI functionality.  
The createGUI() function in this module creates the GUI elements, and launches a GUI.

 
Pre-requisites:
-----------------------------------------------
The only requirement is to have Python installed.
 
Example Usage:
-----------------------------------------------
The following lines demonstrates how to launch the GUI via python comand line.
1. Browse to the folder containing the source code.
2. Execute the script "Launch_GUI.py" entering the following line in the command prompt "python Launch_GUI.py ".
3. A GUI will be launched, using which the user can provide the input TA (in UPPAAL format stored as .xml) and check its class. 
#
######################################################
######################################################


 




