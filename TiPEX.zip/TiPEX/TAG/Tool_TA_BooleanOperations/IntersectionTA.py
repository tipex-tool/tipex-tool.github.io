import pyuppaal
###########################################################################################################
### Method to perform Intersection of two TAs.#####
### Input: Two TAs(in the form of UPPAAL template) on which the Intersection operation has to be performed####
### Output: TA which is the result of the Intersection of the two input TAs.#### 
###########################################################################################################
def Intersection(ta1,ta2):
    intersectionTA = pyuppaal.Template("TA_Intersection",
                             declaration=ta1.declaration + "\n" + ta2.declaration)
    ##set of locations in the resulting TA (initially empty)##
    locations = {}
    ##Variable used to count the number of final locations in the resulting TA used for purposes such as labeling locations in the TA.##
    finalLocCounter = 0
    
    
    for loc1 in ta1.locations:
        for loc2 in ta2.locations:
            ##Accepting locations in the input TAs should be named as "Final".## 
            if str(loc1.name) == "Final" and str(loc2.name) == "Final":
                locID = "Final"+str(finalLocCounter)
                finalLocCounter+= 1
            else:
                locID = str(loc1.name) + str(loc2.name) 
            
            l_intersection = pyuppaal.Location(name=locID)
            l_intersection.id = locID
            
            intersectionTA.locations.append(l_intersection)
            locations[(loc1, loc2)] = l_intersection
            if str(loc1.invariant):
                if str(loc2.invariant):
                    l_intersection.invariant = pyuppaal.Label("invariant", str(loc1.invariant) + ' && ' + str(loc2.invariant))
                else:
                    l_intersection.invariant = pyuppaal.Label("invariant", str(loc1.invariant))
            elif str(loc2.invariant):
                l_intersection.invariant = pyuppaal.Label("invariant", str(loc2.invariant))
            if ta1.initlocation == loc1 and ta2.initlocation == loc2:
                intersectionTA.initlocation = l_intersection
      
    for tr1 in ta1.transitions:
        
        for tr2 in ta2.transitions:
            if str(tr1.synchronisation) == str(tr2.synchronisation): 
                tr_intersection = pyuppaal.Transition(source=locations[(tr1.source,tr2.source)], \
                                             target = locations[(tr1.target,tr2.target)], \
                                             synchronisation = str(tr1.synchronisation))
                if str(tr1.guard):
                    if str(tr2.guard):
                        tr_intersection.guard = pyuppaal.Label("guard", str(tr1.guard)+' && '+str(tr2.guard))
                    else:
                        tr_intersection.guard = pyuppaal.Label("guard", str(tr1.guard))
                elif str(tr2.guard):
                    tr_intersection.guard = pyuppaal.Label("guard", str(tr2.guard))
                    
                if str(tr1.assignment):
                    if str(tr2.assignment):
                        tr_intersection.assignment = pyuppaal.Label("assignment", str(tr1.assignment)+', '+str(tr2.assignment))
                    else:
                        tr_intersection.assignment = pyuppaal.Label("assignment", str(tr1.assignment))
                elif str(tr2.assignment):
                    tr_intersection.assignment = pyuppaal.Label("assignment", str(tr2.assignment))
                intersectionTA.transitions.append(tr_intersection)
    return intersectionTA
###########################################################################################################
###########################################################################################################