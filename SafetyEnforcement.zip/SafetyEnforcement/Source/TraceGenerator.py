###########################################################################
##Method to generate a set of timed words, of different length.
##Input: set of actions, set of delays, length of the maximum trace, 
########and increment (defining difference in length of each generated trace)
############################################################################

import random

#
def genTraces(actions, delays, numTraces, increment):
    traces = []

    for i in range(1, numTraces+1):
        length = increment*i
        #print "trace length is..." + str(length)
        trace = genTrace2(actions,delays, length)
        #print "Trace is..." + str(trace)
        traces.append(trace)
    return traces
    #print "Generated traces are..." + str(traces)


def genTrace2(actions, delays, length):
    
    trace = []
    
    for i in range(0,length):
        delay = random.choice(delays)
        act = random.choice(actions)
        trace.append((act,delay))
    return trace

#def genTrace3(actions, delays, length):
#    
#    actionIndex = 0
#    maxActions = actions.__len__()
#    trace = []
#    
#    for i in range(0,length):
#        if actionIndex>maxActions-1:
#            #print "act index is none!!"
#            actionIndex = 0
#            act = actions.__getitem__(actionIndex)
#            #print "act is.."+ str(act)
#        else:
#            act = actions.__getitem__(actionIndex)
#            #print "act is ..." + str(act)
#        actionIndex = actionIndex+1
#        delay = random.choice(delays)
#        trace.append((act,delay))
#    return trace
#
#def genTrace(actions, delays, length):
#    
#    actionIndex = 0
#    delaysIndex = 0
#    maxActions = actions.__len__()
#    maxDel= delays.__len__()
#    trace = []
#    
#    for i in range(0,length):
#        if actionIndex>maxActions-1:
#            #print "act index is none!!"
#            actionIndex = 0
#            act = actions.__getitem__(actionIndex)
#            #print "act is.."+ str(act)
#        else:
#            act = actions.__getitem__(actionIndex)
#            #print "act is ..." + str(act)
#        
#        if delaysIndex > maxDel-1:
#            delaysIndex = 0
#            delay = delays.__getitem__(delaysIndex)
#        else:
#            delay = delays.__getitem__(delaysIndex)
#    
#        actionIndex = actionIndex+1
#        delaysIndex = delaysIndex+1
#         
#        trace.append((act,delay))
#    return trace

