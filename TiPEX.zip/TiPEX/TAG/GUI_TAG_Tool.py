###################################################################
###################################################################
import os
from Tkinter import *
import Tkinter

import ToolBasicTAgenerator.GUI_BasicTA_Generator as taGen
import Tool_TA_BooleanOperations.GUI_Tool_Combine_TAs as boolOpr
import Tool_TA_ClassIdentifier.GUI_Tool_TA_ClassIdentifier as chkClass
####################################################################
####################################################################

# GUI elements and launching GUI#
window = Tkinter.Tk()
window.title("GTA Tool")
window.minsize(300,150)
window.geometry("300x150")

# Label displaying title # 
title = Label(window, fg="blue",font=6, text= "TAG: Timed Automata Generator")
title.place (x=40, y=10) 
#title.grid(row=0,columnspan=1)
    

#######################
# Function invoked when GenerateTA button is clicked #
def launch_TA_Generator():
    taGen.createGUI()
    
# Function invoked when CombineTAs button is clicked #
def launch_Boolean_Operations():
    boolOpr.createGUI()
 
# Function invoked when CheckClass button is clicked #
def launch_Check_Class():
    chkClass.createGUI()
#########################

# Buttons on the GUI#        
basicTAgen = Tkinter.Button(window, text ="GenerateBasicTA" ,fg = "light blue",
         bg = "dark blue", command = launch_TA_Generator)
basicTAgen.place (x=100, y=45) 

combineTAs = Tkinter.Button(window, text ="   CombineTAs    " ,fg = "light blue",
         bg = "dark blue", command = launch_Boolean_Operations)
combineTAs.place (x=100, y=75) 

checkClass = Tkinter.Button(window, text ="   CheckClass       " ,fg = "light blue",
         bg = "dark blue", command = launch_Check_Class)
checkClass.place (x=100, y=105) 

###########################
window.mainloop()
####################################################################
