import precedencePattern
import absencePattern
import existencePattern
#######################################################################
def generateTA(pattern, complexity, act1, act2, timeConstraint):
    
    if pattern=="Existence":
        existencePattern.generateTA(complexity,act1,act2, timeConstraint)
    elif pattern=="Precedence":
        precedencePattern.generateTA(complexity, act1,act2, timeConstraint)
    elif pattern=="Absence":
        absencePattern.generateTA(complexity, act1,act2, timeConstraint)
    else:
        print "Pattern yet to be defined!!"
########################################################################


