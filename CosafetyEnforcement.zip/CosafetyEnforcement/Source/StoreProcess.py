# Imports
##################################################################
import sys
import os.path
import pyuppaal
import dbmpyuppaal
import pydbm.udbm
import subprocess
import re
import time
import copy
###################################################################

# Current working directory
projdir = os.path.normpath(os.path.join(os.path.dirname(__file__), '..'))
# system path
sys.path = [projdir] + sys.path

##################################################################
###Parsing the input Uppaal model, and other initilizations########
def init(uppaalModel):
    #Some initilizations related to the input Uppaal model, parsing the input model using Pyuppaal and Dbmpyuppaal.
    global Uppaal_Model 
    global model
    # 
    global Parsed_NTA_Pyuppaal 
    global Parsed_NTA_DbmPyUppaal 

    #PA is the automaton representing the property, and RA is the automaton representing the input trace.  
    global PA 
    global RA 

    global CL_RA 
    global CL_PA 
    global ntaState 

    # Need to define which locations are non-accepting the PA.
    #global badLocation 
    global goal_Location 
    ################################################################
    # DBMPYUPPAAL
    global  Property_Automaton 
    global Run_Automaton 
    global Goal_Location 
                
    global ntaInitState 
    global ntaCurrentState 
    global ntaPreviousState
    #################################################################
    #Some initilizations related to the input Uppaal model, parsing the input model using Pyuppaal and Dbmpyuppaal.
    Uppaal_Model = os.path.join(os.path.dirname(__file__), uppaalModel)
    model = uppaalModel
    # 
    Parsed_NTA_Pyuppaal = pyuppaal.NTA.from_xml(open(Uppaal_Model))
    Parsed_NTA_DbmPyUppaal = dbmpyuppaal.parse_xml(uppaalModel)

    #PA is the automaton representing the property, and RA is the automaton representing the input trace.  
    PA = Parsed_NTA_Pyuppaal.templates[0]
    RA = Parsed_NTA_Pyuppaal.templates[1]

    CL_RA = RA.initlocation
    CL_PA = PA.initlocation
    ntaState = (CL_PA, CL_RA)

    ###Need to define which locations are accepting the PA.
    ###Note that in every example property considered, there is one accepting location and is named as "S2".
    
    goal_Location = PA.get_location_by_name("S2")

    ################################################################
    # DBMPYUPPAAL
    Property_Automaton = Parsed_NTA_DbmPyUppaal.getTemplateByName("Property")
    Run_Automaton = Parsed_NTA_DbmPyUppaal.getTemplateByName("Run")
    Goal_Location = Property_Automaton.getLocationByName("S2")
                
    ntaInitState = dbmpyuppaal.NTAState(Parsed_NTA_DbmPyUppaal).delay().extrapolateMaxBounds()
    ntaCurrentState = ntaInitState
    ntaPreviousState = None
    #################################################################
    
#######################################################################
# Function to make a move in the NTA from the current state. 
# Returns the resulting state in the NTA.
#######################################################################
             
def takeTransition(state, transition, delay):
    global Run_Automaton
    
    tr2 = Run_Automaton.transitions[0]
    tr2.guard_str = "y>="+str(delay)
    tr2.guard = dbmpyuppaal.parse_invariant_or_guard("y>="+str(delay), Parsed_NTA_DbmPyUppaal.clocks, Parsed_NTA_DbmPyUppaal.global_consts) or Parsed_NTA_DbmPyUppaal.context.getTautologyFederation()
    tr2.update = dbmpyuppaal.parse_update('y=0', Parsed_NTA_DbmPyUppaal.clocks, Parsed_NTA_DbmPyUppaal.global_consts) 
        
    update = transition.update + tr2.update
    guard = transition.guard & tr2.guard
    target_invariant = transition.target.invariant & tr2.target.invariant
      
    newState = state.copy()
    
    newState.federation &= guard
    fed = newState.federation
    
    if newState.federation.isEmpty():
        return None
    for (clock, value) in update:
        newState.federation = newState.federation.updateValue(clock, value)
    newState.federation &= target_invariant
    if newState.federation.isEmpty():
        return None
    newState.locations[transition.target.template.name] = transition.target
    if tr2:
        newState.locations[tr2.target.template.name] = tr2.source
        
    fed2 = str(newState)
    newState = newState.delay().extrapolateMaxBounds()
    if newState:
        return ((newState,fed2,fed))
    else:
        return None 

######################################################################
#######################################################################
###Returns paths which end in accepting location###########
def getAccPaths(paths):
    global Goal_Location
    acc = []
    for p in paths:
        path = p[1]
        lastState = path.__getitem__(path.__len__()-1)
        lastStateId = lastState.locations["Property"].id
        if lastStateId == Goal_Location.id:
            acc.append(p)
    return acc

######################################################################
###Computes all the possible paths from the initial state for the given input sequence of events.
###################################################################### 
def checkReachabilityCS(events):
    global Property_Automaton
    global Goal_Location
    global ntaInitState
    
    paths = [(ntaInitState,[ntaInitState],[],[])]
    newPaths=[]
    
    for e in events:
        event = e
        act = event[0]
        delay = event[1]
        for p in paths:
            currentState = p[0]
            path = p[1]
            resets = p[2]
            constraints = p[3]
            for transition in Property_Automaton.transitions:
                if transition.source.id == currentState.locations[transition.template.name].id:
                    if str(transition.synchronisation)[0]== act:
                        result = takeTransition(currentState, transition,delay)
                        if result:
                            newState = result[0]
                            newPath = list(path) 
                            newConstraints = list(constraints)
                            newResets = list(resets)
                            newPath.append(newState)
                            newConstraints.append(result[2])
                            newResets.append(result[1])
                            newPaths.append((newState,newPath, newResets, newConstraints))
        paths = newPaths
        newPaths = []
    acceptingPaths = getAccPaths(paths)
    return acceptingPaths
############################################################

############################################################################
##Function to compute extra delay##########################################
## TODO: Need to be replaced with another alternative. ###################
####Currently, clock values are incremented by 1 in each execution of the loop and the guards are checked(can be done more efficiently). ########
def computeExtraDelayCS(conditions,x,y,counter):
    
    extraDelay = 0.0
    for i in range(1,10):
        c = False
        x=x+1.0
        y=y+1.0
        counter=counter + 1.0
        extraDelay = extraDelay+1.0
        
        for i in range(0,conditions.__len__()):
            
            c = conditions[i]
        
            c = c.replace("x", str(x))
            c = c.replace("y", str(y))
            res = eval(c)
            if res:
                c = True
            else:
                c = False
                break
        if c == True:
            return extraDelay  
        
##################################################################################################
##Computes the delays corresponding to each event for a given path
##################################################################################################
def getDelays(path, constraints ,resets, events):
    x=0.0
    y=0.0
    counter=0.0
    pathIndex = 0
    delays = []
    sumDelays = 0.0
    
    for event in events:
        delay= float(event[1])
        x=x+delay
        y=y+delay
        counter=counter + delay
        stateWithResets = resets[pathIndex]
        fed = str(constraints[pathIndex])
        fed=fed.replace("(", "")
        fed=fed.replace(")", "")
        
        conditions = fed.split("&")
        for i in range(0,conditions.__len__()):
            c = conditions[i]
            c = c.replace("x", str(x))
            c = c.replace("y", str(y))
            res = eval(c)
            if not res:
                additionalDelay = computeExtraDelayCS(conditions,x,y,counter)
                break
            else:
                additionalDelay = 0.0
                
        x = x+additionalDelay
        y = y+additionalDelay
        counter = counter+additionalDelay
        delays.append(delay+additionalDelay)
        sumDelays = sumDelays+delay+additionalDelay 
        
        if "y==0" in stateWithResets:
            y = 0.0
            if "x==y" in stateWithResets:
                x = 0.0
        pathIndex = pathIndex+1
    return(sumDelays,delays)

##########################################################
###Picks a path among the set of accepting paths whose sum of delays is minimal.
### Returns the delays corresponding to each event of the optimal path.
##########################################################
def getOptimalDelays(paths, events):
    optimalDelays = []
    optimalSum = None
    
    for p in paths:
        path = p[1]
        constraints = p[3]
        resets= p[2]
        result = getDelays(path, constraints, resets, events)
        if optimalSum==None:
            optimalSum = result[0]
            optimalDelays= result[1]
        else:
            if optimalSum > result[0]:
                optimalSum = result[0]
                optimalDelays = result[1]
    return optimalDelays

##################################################################################################
############ Checks if an accepting state is reachable in the TA from the initial state,
#############upon the sequence of events provided as input.
############ In case if an accepting state is reachable, then optimal delays are computed and returned as a result.
##################################################################################################
def update(events):
    acceptingPaths = checkReachabilityCS(events)
    if acceptingPaths.__len__() == 0:
        return False
    else:
        delays = getOptimalDelays(acceptingPaths, events)
        return delays
#################################################################################################### 

  
####### The store method.##############################################################
####### INPUT parameters #####
##########-- uppaalModel--UPPAAL model as xml, containing automaton representing the property#######
##########--inputTrace--input timed word##############################################
##########OUTPUT -- returns the total execution time of the update for the given input trace########
#################################################################################################### 
def store(uppaalModel, inputTrace):
    events = [] 
    GoalReached = False
    TotalUpdateTime = 0.0
    init(uppaalModel)
    traceLength = inputTrace.__len__()

    for i in range(0,traceLength):
        event = inputTrace.__getitem__(i)
        #print "Store process received input..." + str(event)
        if (GoalReached):
            #print "Accepting state already reached!!..monitor can turn off!!"
            return(TotalUpdateTime)
        else:
            events.append(event)
            t1 = time.time()
            optimalDelays = update(events)
            t2 = time.time()
            #print "time taken by update is.." + str(t2-t1)
            TotalUpdateTime = TotalUpdateTime+(t2-t1)
            if (optimalDelays == False):
                continue
            else:
               GoalReached=True
               #print "optimal delays are..." + str(optimalDelays)
               return (TotalUpdateTime)
########################################################################################
########################################################################################
           
            
