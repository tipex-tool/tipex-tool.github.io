######################################################
TAG: Timed Automata Generator (Boolean Operations) 
version alpha: January 2015
=============================================
-= License =-
This software is provided under the license GPL.
######################################################
#
About:
--------
This folder contains a tool implementation to combine (complete and deterministic) timed automata using certain Boolean operations such as Union and Intersection.

- "IntersectionTA.py":
   This module implements the "Intersection" function which takes two TAs (as UPPAAL templates) as input and returns a TA (UPPAAL template), which is the result of performing intersection of the given input TAs.
   
- "UnionTA.py": 
  This module implements the "Union" function which takes two TAs (as UPPAAL templates) as input and returns a TA (UPPAAL template), which is the result of performing union of the given input TAs.

- "mainTester.py": 
   This module contains a test function implemented to test the intersection and union operations.
   The "testBooleanOperationsTAs" function takes as input:
    - an UPPAAL model (stored as .xml), which should contain two input TAs (defined as two different templates). Note that in the input TAs, accepting locations should be named as "FINAL". 
	- and the operation to be performed (should be a string either "union" or "intersection").

- "GUI_Tool_CombineTAs.py":
	This module implements the GUI functionality.  
	The createGUI() function in this module creates the GUI elements, and launches a GUI.
    Invoking createGUI() function will launch a small user interface, allowing user to select the input UPPAAL model, and the operation , and to perform the operation.
	NOTE: The input UPPAAL model (stored as .xml) selected by the user, should contain two input TAs (defined as two different templates). 
	      Note that in the input TAs, accepting locations should be named as "FINAL".
##################################################################################################
##################################################################################################

Pre-requisites:
-----------------
The only requirement is to have Python installed.
Note that the version of Python used was Python 2.7.  

Example Usage:
-----------------
The following lines demonstrates how to launch the GUI via Python command line.
1. Browse to the folder containing the source code.
2. Execute the script "Launch_GUI.py" entering the following line in the command prompt "python Launch_GUI.py ".
3. A GUI will be launched, using which the user can select the operation, and a file containing the input TAs.
##################################################################################################
##################################################################################################
 
 
 