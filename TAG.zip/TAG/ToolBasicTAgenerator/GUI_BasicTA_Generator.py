####################################################################
####################################################################
import os
from Tkinter import *
import Tkinter
import tkMessageBox
import taGenerator
####################################################################
####################################################################

###Create the GUI elements and launch the GUI####### 
def createGUI():
    window = Tkinter.Tk()
    window.title("Generate TA")
    window.minsize(350,220)
    window.geometry("350x220")
    # Label to display title##
    title = Label(window, fg="blue",font=6,  text= "Generate TA", anchor=W)
    title.grid(row=0, columnspan =3, column=1, sticky=W)
    
    ## Variable to store the path of the UPPAAL executable ##
    UppaalExePath = StringVar()

    ###########################
    # TA Pattern 
    L2 = Label(window, text="Pattern")
    L2.grid(row=1, column=0, sticky=W)

    pattern = StringVar(window)
    pattern.set("Absence") # default value
    p = OptionMenu(window, pattern, "Precedence", "Existence", "Absence")
    p.grid(row=1, column=1, sticky=W)
    ###########################

    ###########################
    ## Input Action 1
    A1 = Label(window, text="Action1")
    A1.grid(row=2,sticky=W)
    E1 = Entry(window,width=6, bd =2)
    E1.grid(row=2,column=1, sticky=W)


    ## Input Action 2
    A2 = Label(window, text="Action2")
    A2.grid(row=2,column=3)
    E2 = Entry(window, width=6,bd =2)
    E2.grid(row=2,column=4, sticky=E)

    ###########################
    # TA Complexity
    L3 = Label(window, text="Complexity")
    L3.grid(row=3, column=0, sticky=W)

    complexity = Entry(window, width=5,bd =2)
    complexity.grid(row=3, column=1, sticky=W)

    ############################

    ###########################
    # Value to be used for guards on transitions.
    L4 = Label(window, text="Time Constraint Value")
    L4.grid(row=4, column=0, sticky=W)

    timeConstraint = Entry(window,width=5, bd =2)
    timeConstraint.grid(row=4,column=1, sticky=W)
    ###########################

    ###########################
    # Path where the UPPAAL executable is located
    L5 = Label(window, text="UPPAAL .jar path")
    L5.grid(row=5, column=0, sticky=W)

    uppaalPath = Entry(window,width=19, bd =2)
    uppaalPath.grid(row=5,column=1, sticky=W)
    ###########################

    ###########################
    ## Function that will be invoked when the generateTA button is clicked.
    def generateTA():
        print os.path.dirname(os.path.realpath(__file__))
        print "Action 1 is:"+str(E1.get())+"; " +"Action 2 is:"+str(E2.get())+"; " + "Pattern is:" + str(pattern.get()) + "; Complexity is: "+ str(complexity.get())
        
        if (E1.get() == "" or E2.get() == "" or pattern.get()== "" or complexity.get()==""):
            tkMessageBox.showinfo( "Message", "Action1, Action2, Pattern, and Complexity cannot be left empty." )
                    
        if (not(complexity.get().isdigit()) or int(complexity.get())<=0):
            tkMessageBox.showinfo( "Message", "Complexity should be a positive number." )
            
        if (not(timeConstraint.get().isdigit()) or int(timeConstraint.get())<=0):
            tkMessageBox.showinfo( "Message", "Time constraint should be a positive number." )
            
        else:
            taGenerator.generateTA(str(pattern.get()), int(complexity.get()), E1.get(), E2.get(), timeConstraint.get())
            tkMessageBox.showinfo( "Message", "TA is generated, and is written to file Example_Gen.xml" )

    ################################
    # Function that will be invoked when the openProperty button is clicked.
    def openProperty():
        if (uppaalPath.get()==""):
            tkMessageBox.showinfo( "Message", "To view the generated file in UPPAAL, please provide path where UPPAAL executable is located in the field 'UPPAAL .jar path ' " )
            
        if (os.path.isfile(str(UppaalExePath.get()))):
            tkMessageBox.showinfo( "Message", "The entered path is invalid. Please provide a valid path where UPPAAL executable is located in the field 'UPPAAL .jar path ' " )
        
        else:            
            UppaalExePath.set(uppaalPath.get())
            os.system( str(UppaalExePath.get())+' Example_Gen.xml' )
#   #################################

    # Buttons on the GUI
    generateTAButton = Tkinter.Button(window, text ="     GenerateTA     " , fg = "light blue",
         bg = "dark blue", command = generateTA)
    generateTAButton.place(x=120, y=150)
    
    openPropButton = Tkinter.Button(window, text ="ViewGeneratedTA", fg = "light blue",
         bg = "dark blue", command = openProperty)
    openPropButton.place(x=120, y=180)
    #################################    
    
    window.mainloop()

########################################################################################
