import pydbm

from distutils.core import setup, Extension

setup(
        name = 'dbmpyuppaal',
        version = '0.1',
        package_dir = {'dbmpyuppaal': ''},
        packages = ['dbmpyuppaal'],
     )
