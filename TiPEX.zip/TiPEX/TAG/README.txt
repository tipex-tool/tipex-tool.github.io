######################################################
TAG: Timed Automata Generator 
version alpha: January 2015
=============================================
-= License =-
This software is provided under the license GPL.
######################################################
#
About:
--------
This folder contains implementation of a tool called as TAG for Generation of Timed Automata.
This tool supports features such as:
     - Generating basic TA, by providing some data such as pattern, actions, complexity and time constraint constants.
     - Combining TAs using Boolean operations.
     - Checking the class to which a TA belongs.	 

The following items are contained in this folder.
1. GUI_TAG_Tool.py
A GUI, providing access to all the above functionality (to generate basic TA, combine TAs, and checking class of a TA).    

2. ToolBasicTAgenerator
This folder contains all the files (source, README, examples) related to basic TA generator. 

3. Tool_TA_BooleanOperations
This folder contains all the files (source, README, examples) related to combining TAs using Boolean operations. 

4. Tool_TA_ClassIdentifier
This folder contains all the files (source, README, examples) related to checking class of a TA. 


Pre-requisites:
---------------
The only requirement is to have Python installed.
Note that the version of Python used was Python 2.7.

 
Example Usage:
--------------
The following lines demonstrates how to launch the GUI via python command line.
1. Browse to the folder containing the source code (which contains the file "GUI_TAG_Tool.py").
2. Execute the script "GUI_TAG_Tool.py" entering the following line in the command prompt "python GUI_TAG_Tool.py ".
3. A GUI will be launched, using which the user can select to generate a basic TA, or to combine TAs, or to check the class of a TA. 
#
######################################################
######################################################