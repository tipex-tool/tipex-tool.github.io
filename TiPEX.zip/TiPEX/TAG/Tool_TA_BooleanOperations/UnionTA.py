import pyuppaal
###########################################################################################################
### Method to perform Union of two TAs.#####
### Input: Two TAs(in the form of UPPAAL template) on which the Union operation has to be performed####
### Output: TA which is the result of the Union of the two input TAs.#### 
###########################################################################################################
def Union(ta1,ta2):
    
    TA_union = pyuppaal.Template("TA_Union", declaration=ta1.declaration + "\n" + ta2.declaration)
    ##set of locations in the resulting TA (initially empty)##
    locations = {}
    ##Variable used to count the number of final locations in the resulting TA used for purposes such as labeling locations in the TA.##
    finalLocCounter = 0
     
    for loc1 in ta1.locations:
        for loc2 in ta2.locations:
            ##Accepting locations in the input TAs should be named as "Final".##  
            if str(loc1.name)!= "Final" and str(loc2.name)!= "Final":
                locID = str(loc1.name) + str(loc2.name)
                
            else:
                locID = "Final"+ str(finalLocCounter)
                finalLocCounter+= 1
                
            l_union = pyuppaal.Location(name=locID)
            l_union.id = locID
            
            TA_union.locations.append(l_union)
            locations[(loc1, loc2)] = l_union
            if str(loc1.invariant):
                if str(loc2.invariant):
                    l_union.invariant = pyuppaal.Label("invariant", str(loc1.invariant) + ' && ' + str(loc2.invariant))
                else:
                    l_union.invariant = pyuppaal.Label("invariant", str(loc1.invariant))
            elif str(loc2.invariant):
                l_union.invariant = pyuppaal.Label("invariant", str(loc2.invariant))
            if ta1.initlocation == loc1 and ta2.initlocation == loc2:
                TA_union.initlocation = l_union
 
      
    for tr1 in ta1.transitions:
        for tr2 in ta2.transitions:
            if str(tr1.synchronisation) == str(tr2.synchronisation): 
                #target = locations[(tr1.target,tr2.target)]
                tr_union = pyuppaal.Transition(source=locations[(tr1.source,tr2.source)], \
                                             target = locations[(tr1.target,tr2.target)], \
                                             synchronisation = str(tr1.synchronisation))
                if str(tr1.guard):
                    if str(tr2.guard):
                        tr_union.guard = pyuppaal.Label("guard", str(tr1.guard)+' && '+str(tr2.guard))
                    else:
                        tr_union.guard = pyuppaal.Label("guard", str(tr1.guard))
                elif str(tr2.guard):
                    tr_union.guard = pyuppaal.Label("guard", str(tr2.guard))
                    
                if str(tr1.assignment):
                    if str(tr2.assignment):
                        tr_union.assignment = pyuppaal.Label("assignment", str(tr1.assignment)+', '+str(tr2.assignment))
                    else:
                        tr_union.assignment = pyuppaal.Label("assignment", str(tr1.assignment))
                elif str(tr2.assignment):
                    tr_union.assignment = pyuppaal.Label("assignment", str(tr2.assignment))
                TA_union.transitions.append(tr_union)
    
    return TA_union

###########################################################################################################
###########################################################################################################

