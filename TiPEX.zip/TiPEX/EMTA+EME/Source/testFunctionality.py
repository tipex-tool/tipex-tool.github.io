###########################################################
####To test the functionality (input-output behavior) of the StoreProcess 
####Invokes store method with an input trace, the property (and list of accepting locations in the property).
#############################################################
import StoreProcess
#########################################################


########################################################
####### "testStoreProcess" is the main test method which invokes the store method 
####### with differrent properties and input traces (to check the expected output for the provided input).
########################################################
def testStoreProcess(property, accLoc, inputTrace):
    
    print "property is:" + str(property)
    print "Input seq is: " + str(inputTrace)
    result=StoreProcess.store(property, accLoc, inputTrace)
    print "Output of Store is" + str(result[1])
    #
#####################################################################################



##Input property "Example_Safety.xml"####
### (A safety property expressing that "There should be atleast 5 t.u between any two "r" actions)###
############# sigma = {a,r}, Sample input trace = "('a',1),('r',3),('r',1)"###
testStoreProcess('Example_Safety.xml', ["S1", "S2"], [('a',1),('r',3),('r',1)])

print "#####################################################################"
print "#####################################################################"

##Input property "Co-SafetyExistanceP1.xml"####
###(A co-safety property expressing that "The first R action should be immediately followed by a "G" action, and there should be a delay of atleast 6 t.u between them")##
############# sigma = {G,R}, Sample input trace = "('R',5),('G',3),('R',1)"###
testStoreProcess('Example_CoSafety.xml', ["S2"], [('R',5),('G',3),('R',1)])

print "#####################################################################"
print "#####################################################################"



#Input property "response1.xml"####
###(A regular property expressing that "Resource grant and release should alternate starting with a grant, and every grant should be released with in 15 to 20 t.u.")##
############# sigma = {G,R,A}, Sample input trace = "('G',3),('R',10),('G',3), ('G',5)"###
testStoreProcess('Example_Response.xml', ["S0"], [('G',3),('R',10),('G',3), ('G',5)])

print "#####################################################################"
print "#####################################################################"


#####################################################################################












