import sys
import checkPropertyClass 

############################################################################################
############################################################################################
## A test method to test the checkClass and inEnforceable methods with different inputs. ##
def test(inputTA):
    print "Input UPPAAL model is: " + inputTA
    print "Invoking check class.."
    checkPropertyClass.checkClass(inputTA)
    

############################################################################################
############################################################################################
## Test with some input TAs ##
## Input TA is a UPPAAL model stored as .xml##
test("ExampleTAs/Safety1.xml")
print "########################################################"
test("ExampleTAs/Safety2.xml")
print "########################################################"
test("ExampleTAs/Safety3.xml")
print "########################################################"
#
test("ExampleTAs/Co-Safety1.xml")
print "########################################################"
test("ExampleTAs/Co-Safety2.xml")
print "########################################################"

test("ExampleTAs/Response1.xml")
print "########################################################"
test("ExampleTAs/Response2.xml")
print "########################################################"
############################################################################################
############################################################################################