# Imports
##################################################################
import sys
import os.path
import pyuppaal
import dbmpyuppaal
#import pydbm.udbm
import subprocess
import re
import time
import copy
###################################################################

# Current working directory
projdir = os.path.normpath(os.path.join(os.path.dirname(__file__), '..'))
# system path
sys.path = [projdir] + sys.path

####################################################################

###Parsing the input Uppaal model, and other initilizations########
def init(uppaalModel):
    #Some initilizations related to the input Uppaal model, parsing the input model using Pyuppaal and Dbmpyuppaal.
    global Uppaal_Model 
    global model
     
    global Parsed_NTA_Pyuppaal 
    global Parsed_NTA_DbmPyUppaal 

    #PA is the automaton representing the property, and RA is the automaton representing the input trace.  
    global PA 
    global RA 

    global CL_RA 
    global CL_PA 
    global ntaState 

    # Need to define which locations are non-accepting the PA.
    global badLocation 

    #get the id of L0 in the run automaton
    global location 
    global locationIDcount 
    global locationLableCount 
    global locXpos 
    global locYpos 

    ################################################################
    # DBMPYUPPAAL
    global  Property_Automaton 
    global Run_Automaton 
    global Bad_Location 
                
    global ntaInitState 
    global ntaCurrentState 
    global ntaPreviousState
    #################################################################
    ###Clocks#############
    global x
    global y
    global counter
    ######################    
    global Assign
    global tr2Update
    global fed
    global fed2
    #########################

    #Some initilizations related to the input Uppaal model, parsing the input model using Pyuppaal and Dbmpyuppaal.
    Uppaal_Model = os.path.join(os.path.dirname(__file__), uppaalModel)
    model = uppaalModel
    # 
    Parsed_NTA_Pyuppaal = pyuppaal.NTA.from_xml(open(Uppaal_Model))
    Parsed_NTA_DbmPyUppaal = dbmpyuppaal.parse_xml(uppaalModel)

    #PA is the automaton representing the property, and RA is the automaton representing the input trace.  
    PA = Parsed_NTA_Pyuppaal.templates[0]
    RA = Parsed_NTA_Pyuppaal.templates[1]

    CL_RA = RA.initlocation
    CL_PA = PA.initlocation
    ntaState = (CL_PA, CL_RA)

    ####Need to define which locations are non-accepting the automaton representing the property.
    ###Note that in every example property considered, there is one non-accepting location and is named as "S3".
    badLocation = PA.get_location_by_name("S3")

    #get the id of L0 in the run automaton
    location = RA.initlocation
    locationIDcount = int((CL_RA.id)[-1])+1
    locationLableCount = 1
    locXpos = CL_RA.xpos
    locYpos = CL_RA.ypos

    ################################################################
    # DBMPYUPPAAL
    Property_Automaton = Parsed_NTA_DbmPyUppaal.getTemplateByName("Property")
    Run_Automaton = Parsed_NTA_DbmPyUppaal.getTemplateByName("Run")
    Bad_Location = Property_Automaton.getLocationByName("S3")
    
                
    ntaInitState = dbmpyuppaal.NTAState(Parsed_NTA_DbmPyUppaal).delay().extrapolateMaxBounds()
    ntaCurrentState = ntaInitState
    ntaPreviousState = None
    #################################################################
    
    ###Clocks#############
    ##Note that in the example properties, there is only two clocks in the uppaal model. 
    ###Only one clock named "x" in the automaton modeling the property###############
    x=0.0
    y=0.0
    counter=0.0
    ######################    
    Assign="None"
    tr2Update="None"
    fed = "None"
    fed2 = "None"
    #########################

#######################################################################
#### make a move in the TA and 
#### return the resulting state 
#######################################################################
             
def takeTransition(state, transition):
    global fed 
    global fed2
    global Run_Automaton
    
    ### Note that Run_Automaton contains only one transition, with the input event, and a guard on clock y "y>=n" where n is the delay corresponding to the input event,
    ###and a reset of clock y.        
    tr2 = Run_Automaton.transitions[0]
    
    ### Transition is the transition we want to take in the automaton modeling the property.
    update = transition.update + tr2.update
    guard = transition.guard & tr2.guard
    target_invariant = transition.target.invariant & tr2.target.invariant
      
    newState = state.copy()
    
    newState.federation &= guard
    fed = newState.federation
    
    if newState.federation.isEmpty():
        return None
    for (clock, value) in update:
        newState.federation = newState.federation.updateValue(clock, value)
    newState.federation &= target_invariant
    if newState.federation.isEmpty():
        return None
    newState.locations[transition.target.template.name] = transition.target
    if tr2:
        newState.locations[tr2.target.template.name] = tr2.source
        
    fed2 = str(newState)
    newState = newState.delay().extrapolateMaxBounds()
    return newState 

###########################################################################################
###Check if there is a transition from the current state in the automaton modeling the property with an action matching the input "event" and the target location is also accepting### 
###If such a transition exists, then make a move in the automaton and return the resulting state reached, ###
###if the guards also can be satisfied wrt the delay corresponding to the received input event.#########
###########################################################################################
def checkReachability(event):
    global Property_Automaton
    global Bad_Location
    global ntaCurrentState
    global ntaPreviousState
    act = event[0]
    delay = event[1]
    
    #print "NTA state is..." + str(ntaCurrentState)
    
    for transition in Property_Automaton.transitions:
                
                if not transition.source.id == ntaCurrentState.locations[transition.template.name].id:
                    continue
                if not (str(transition.synchronisation)[0]== act):
                    continue
                if transition.target == Bad_Location: 
                    continue
                #print "A matching transition in property is found..source state is.." +str(transition.source) + "..sync is.." + str(transition.synchronisation)
                
                #make a move in the NTA. "takeTransition returns the resulting NTA state."
                newState = takeTransition(ntaCurrentState, transition)
                if newState:
                    #print "New NTA state after transition is..." + str(newState)
                    ntaPreviousState = ntaCurrentState
                    ntaCurrentState = newState
                    return True   
    return False 
############################################################


#######################################################################################################################################
##Function to compute extra delay######################################################################################################
## !!!TODO!!!: Need to be replaced with another alternative. ##########################################################################
####Currently, clock values are incremented by 1 in each execution of the loop and the guards are checked(not very efficient). ########
#######################################################################################################################################
def computeExtraDelay(conditions):
    global x
    global y
    global counter    
    extraDelay = 0.0
    while True:
        c = False
        x=x+1.0
        y=y+1.0
        counter=counter + 1.0
        extraDelay = extraDelay+1.0
        
        for i in range(0,conditions.__len__()):
            
            c = conditions[i]
            c = c.replace("x", str(x))
            c = c.replace("y", str(y))
            res = eval(c)
           # print res
            if res:
                c = True
            else:
                c = False
                break
        if c == True:
            return extraDelay  

##################################################################################################
# function to manage clock values.#########
### Also computes and returns the delay#### 
##################################################################################################
def updateClocks(fed, event):
    global x
    global y 
    global counter
    delay= float(event[1])
    
    #update the clocks and counter. Increment them with delay.
    x=x+delay
    y=y+delay
    counter=counter + delay
    #print "clock values are.."+"x="+str(x)+"y="+str(y)
    # Check if the clock values satisfy all the conditions.
    fed= str(fed)
    fed=fed.replace("(", "")
    fed=fed.replace(")", "")
        
    conditions = fed.split("&")
    #print "conditions are..." + str(conditions)    
    for i in range(0,conditions.__len__()):
            
        c = conditions[i]
        c = c.replace("x", str(x))
        c = c.replace("y", str(y))
        res = eval(c)
        if not res:
            newDelay = computeExtraDelay(conditions)
            #print newDelay
            return delay+newDelay
    return delay

##################################################################################################
# Function to check the conditions and reset the clocks.          
##################################################################################################
def resetClocks(resets):                
# Check for resets, any reset the clocks.
    global y
    global x
    if "y==0" in resets:
        y = 0.0
        if "x==y" in resets:
            x = 0.0
                

############################################################################################################################
#### In the Uppaal model, there is another automaton representing the input event with two locations and one transition.####
####This function updates the action and the guard associated with this transition upon each event##########################
############################################################################################################################
def updateTransitionRA(event):
    global Run_Automaton
    global Parsed_NTA_DbmPyUppaal
    delay = event[1]
    tr2 = Run_Automaton.transitions[0]
    tr2.guard_str = "y>="+str(delay)
    tr2.guard = dbmpyuppaal.parse_invariant_or_guard("y>="+str(delay), Parsed_NTA_DbmPyUppaal.clocks, Parsed_NTA_DbmPyUppaal.global_consts) or Parsed_NTA_DbmPyUppaal.context.getTautologyFederation()
    tr2.update = dbmpyuppaal.parse_update('y=0', Parsed_NTA_DbmPyUppaal.clocks, Parsed_NTA_DbmPyUppaal.global_consts) 
##################################################################################################


##################################################################################################
############ Checks if the NTA is in a Good location.############################################
def update(ntaState, event):
    global fed
    
    ## Check reachability method checks if there is an accepting state from the current state upon "event",
    ## and takes a transition leading to an accepting transition in case if there is a path.
    res = checkReachability(event)
    if res == True:
        ##update the clock values, and get the value of the delay.
        delay = updateClocks(fed, event)
        return (True,event[0],delay)
    else:
        return (False,event)
#################################################################################################### 
       
####### The store method.##############################################################
####### INPUT parameters #####
##########-- uppaalModel--Uppaal model as xml, containing automaton representing the property#######
##########--inputTrace--input timed word##############################################
##########OUTPUT -- returns the total execution time of the update for the given input trace########
#################################################################################################### 

def store(uppaalModel, inputTrace):
    global ntaState
    global fed2
    
    TotalUpdateTime = 0.0
    
    #call to the init method to parse the input uppaal model and perform some initilizations.
    init(uppaalModel)
    traceLength = inputTrace.__len__()
    #print "trace length is ..." + str(traceLength)
    
    ##for each event in the input trace, invoke the update function#############
    for i in range(0,traceLength):
        event = inputTrace.__getitem__(i)
        #print "Store process received input..." + str(event)
        # update the automaton representing the input event (with event). 
        updateTransitionRA(event)
        
        t1 = time.time()
        ###invoke update with the current state information, and current event.
        res = update(ntaState, event)
        t2 = time.time()
        TotalUpdateTime = TotalUpdateTime+(t2-t1)
        #print "Update time is .." + str(t2-t1)

        #if update returns false, there there is no possible path to an accepting state.
        if (res[0] == False):
            #print "Property cannot be satisfied anymore!! Halt Enforcer!!!!"
            break
        else:
            #print "Store process output event is.." + str((res[1],res[2]))
            ##reset the clocks (which are in the set of resets in the transition taken).
            resetClocks(fed2)
    #print "total update time is.." +  str(TotalUpdateTime)
    return (TotalUpdateTime)
 ########################################################################################
           
            
