###########################################################################
##Method to generate a set of timed words, of different length.
##Input: set of actions, set of delays, length of the maximum trace, 
########and increment (defining difference in length of each generated trace)
############################################################################

import random

#
def genTraces(actions, delays, numTraces, increment):
    traces = []

    for i in range(1, numTraces+1):
        length = increment*i
        trace =  genTraceCSp1(actions,delays,length)
        traces.append(trace)
    return traces


def genTraceResp1(actions, delays, length):
    
    trace = []
    act1 = actions.__getitem__(0)
    act2 = actions.__getitem__(1)
    for i in range(0,length/2):
        trace.append((act1,random.choice(delays)))
        trace.append((act2,random.choice(delays)))
    
    return trace

def genTraceCSp1(actions, delays, length):
    
    trace = []
    act = actions.__getitem__(0)
    for i in range(0,length-2):
        delay = random.choice(delays)
        trace.append((act,delay))
    trace.append((actions.__getitem__(1),random.choice(delays)))
    trace.append((act,random.choice(delays)))
    return trace

def genTraceCSp2(actions, delays, length):
    
    trace = []
    act = actions.__getitem__(0)
    for i in range(0,length-6):
        delay = random.choice(delays)
        trace.append((act,delay))
    for i in range(1,6):
        trace.append((actions.__getitem__(1),random.choice(delays)))
    trace.append((act,random.choice(delays)))
    return trace


def genTrace2(actions, delays, length):
    
    trace = []
    trace.append(('c',2))
    trace.append(('c',2))
    for i in range(0,length):
        delay = random.choice(delays)
        act = random.choice(actions)
        trace.append((act,delay))
    return trace

def genTrace3(actions, delays, length):
    
    actionIndex = 0
    maxActions = actions.__len__()
    trace = []
    
    for i in range(0,length):
        if actionIndex>maxActions-1:
            actionIndex = 0
            act = actions.__getitem__(actionIndex)
            
        else:
            act = actions.__getitem__(actionIndex)
            
        actionIndex = actionIndex+1
        delay = random.choice(delays)
        trace.append((act,delay))
    return trace

def genTrace(actions, delays, length):
    
    actionIndex = 0
    delaysIndex = 0
    maxActions = actions.__len__()
    maxDel= delays.__len__()
    trace = []
    
    for i in range(0,length):
        if actionIndex>maxActions-1:
            actionIndex = 0
            act = actions.__getitem__(actionIndex)
        else:
            act = actions.__getitem__(actionIndex)
        
        if delaysIndex > maxDel-1:
            delaysIndex = 0
            delay = delays.__getitem__(delaysIndex)
        else:
            delay = delays.__getitem__(delaysIndex)
    
        actionIndex = actionIndex+1
        delaysIndex = delaysIndex+1
         
        trace.append((act,delay))
    return trace

