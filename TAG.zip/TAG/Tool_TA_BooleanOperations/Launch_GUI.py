import GUI_Tool_Combine_TAs
GUI_Tool_Combine_TAs.createGUI()

