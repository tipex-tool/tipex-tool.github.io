import sys
import os.path
import shutil
import pyuppaal
############################################################################################
############################################################################################

## Provides the class to which a TA belongs (safety , so-safety or other) ################# 
def checkClass(uppaalModelPath):
    
    Parsed_NTA_Pyuppaal = pyuppaal.NTA.from_xml(open(uppaalModelPath))
    ta = Parsed_NTA_Pyuppaal.templates[0]
 
    if isSafety(ta)== True:
        print "Input TA defines a Safety property!!"
        return "Safety"
    elif isCoSafety(ta)==True:
        print "Input TA defines a Co-safety property!!"
        return "Co-safety"
    else:
        print "Input TA is neither Safety nor Co-safety!!"
        return "Other"


############################################################################################
############################################################################################

## Checks whether the TA given as input defines a Safety property. ####
## returns "true" if the TA is a Safety TA and "false" otherwise.  ####
def isSafety(ta):
    for transition in ta.transitions:
        if str(transition.source.name) =="Bad":
            if str(transition.target.name) != "Bad":
                return False
            else:
                continue
    return True
    
############################################################################################
############################################################################################

## Checks whether the TA given as input defines a co-safety property. ####
## returns "true" if the TA is a co-safety TA and "false" otherwise.  ####
 
def isCoSafety(ta):
    for transition in ta.transitions:
        if str(transition.source.name) != "Bad":
            if str(transition.target.name) != "Bad":
                continue
            else:
                return False
    return True

############################################################################################
############################################################################################







