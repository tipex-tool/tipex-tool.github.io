###########################################################
##TestStoreProcess is the method to get the performance 
###results of the store method.
####Uses trace generator to get a set of traces.
####Invokes store method with each input trace, and the property,
#### and stores the trace length, and the total execution time of update returned by the store method.
#############################################################


########################################################
##Input properties considered for test####
###Property1: Absence1.xml (There cannot be two 'a' actions in every 5 time units.)
############# sigma = {a,b,c}, delays = {1,2,3,4,5}
###Property2: Precedence1.xml (Action 'a' enables action 'b' after a delay of 10 t.u.)
############# sigma = {a,b,c}, delays = {1,2,3,4,5}
########################################################
import time
from threading import Timer
import sys
import os.path
import shutil
#########################################################
import StoreProcess
import TraceGenerator
########################################################


#### "testStoreProcess" is the main test method which invokes the store method 
#######with the property and an input trace and keeps track of the execution time results returned by the store method.
def testStoreProcess(property, actions, delays, numTraces, incrementPerTrace):
    testResults = []
    
    ##invoke the trace generator method. 
    ###Store the result returned in "inputTraces"
    ####Parameters are possible actions, possible delays, number of traces and increment in length per trace.
    inputTraces = TraceGenerator.genTraces(actions, delays, numTraces, incrementPerTrace)
    
    
    ###invoking the store method for each input trace.
    for i in range(0,inputTraces.__len__()):
        #f = open("Example_SafetyGen.xml", "w")
        
        shutil.copy(property, "Example_Safety_Gen.xml")
        propertyC = "Example_Safety_Gen.xml"
        
        trace = inputTraces.pop()
        traceLength = trace.__len__()
        #print "input trace is.." + str(trace)

        ##For each trace, invoke the store for "n" number of times, to take an average of the execution time per trace over multiple runs.
        testResultsPerTrace = []
        for j in range(1,10):
            updateTime = StoreProcess.store(propertyC,trace)
            #print "store returned..." + str(updateTime)
            testResultsPerTrace.append((traceLength, updateTime, updateTime/traceLength))
    
        #print "TEst results.." + str(testResults)
        Sum_tot = 0.0
        Sum_per = 0.0
            
        ### Compute average per trace and store the result in "testResults"
        for i in range(0,testResultsPerTrace.__len__()):
            #print "testres.." + str(testResults[i][1])
            Sum_tot = Sum_tot + testResultsPerTrace[i][1]
            Sum_per =  Sum_per + testResultsPerTrace[i][2]
        Avg_t = Sum_tot/testResultsPerTrace.__len__()
        Avg_p = Sum_per/testResultsPerTrace.__len__()
        testResults.append((traceLength, Avg_t, Avg_p))
        #print "Avg total.." + str(Avg_t)
        #print "Avg_per.." + str(Avg_p)
    print "Test results.." + str(testResults)    

##invoking the main test method        
#testStoreProcess('Example_Safety.xml', ['a','b','c'], [1,2,3,4,5], 4, 10)

if __name__ == "__main__":
    property = (sys.argv[1])
    events = (sys.argv[2])
    delays = (sys.argv[3])
    numTraces = int(sys.argv[4])
    incrPerTrace = int(sys.argv[5])
    testStoreProcess(property, events, delays, numTraces,incrPerTrace)

    
    
    
    








