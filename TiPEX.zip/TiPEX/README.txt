######################################################
TiPEX: a tool chain for Timed Property Enforcement
during eXecution
version alpha: January 2015
=============================================
-= License =-
This software is provided under the license GPL.
######################################################
#
About:
--------
This folder contains implementation of a tool called as TiPEX.

The source code and some examples are provided. 
The archive contains two directories:
   - The EMTA+EME/ directory  consists of source code and other material 
     related to implementation of enforcement monitoring algorithms and functionalities to evaluate performance. 
	 See README file inside this directory for details (prerequisites, usage).
   - The TAG/ directory provides source code and other material related to implementation of generation timed automata from patterns, compose them, 
     and check the class of properties they belong to in order to optimize the monitors. 
	 See README file inside this directory for details (prerequisites, usage).
#
######################################################
######################################################