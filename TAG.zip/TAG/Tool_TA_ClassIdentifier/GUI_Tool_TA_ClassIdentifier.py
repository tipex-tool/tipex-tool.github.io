####################################################################
####################################################################
from Tkinter import *
import Tkinter
import tkMessageBox
import os
from tkFileDialog import askopenfilename

import checkPropertyClass 
####################################################################
####################################################################

###Create the GUI elements and launch the GUI####### 
def createGUI():
    window = Tkinter.Tk()
    window.title("Check class")
    window.minsize(250,100)
    window.geometry("250x100")

    # variable to store the path of the selected file##
    uppaalModel = StringVar()
    uppaalModel.set("No file chosen!!")

    # Label to display title##
    title = Label(window, fg="blue",font=6,  text= "Check TA Class", anchor=W)
    title.place (x=55, y=5) 

    ## Other labels on GUI##
    L1 = Label(window,  text="Uppaal Model")
    L1.place (x=10, y=35) 

    ###############################
    ##Method invoked to choose a file when the button "chooseFile" is clicked##### 
    def openFile():
        Tk().withdraw() 
        filename = askopenfilename() 
        print(filename)
        uppaalModel.set(filename)
    ################################
    ##Method invoked when the button "checkClass" is clicked### 
    def checkClass():
        extension = os.path.splitext(uppaalModel.get())[-1].lower()
        
        if (uppaalModel.get()=="No file chosen!!"):
            tkMessageBox.showinfo( "status" , "Please select a valid UPPAAL model (.xml) containing the input TAs."   )
        
        
        if (extension <>'.xml'):
            tkMessageBox.showinfo( "status" , "Selected file is not a .xml. Please select a valid UPPAAL model (.xml) containing the input TAs."   )
            
        else:
            propertyClass = checkPropertyClass.checkClass(uppaalModel.get())
            if (propertyClass=="Safety" or propertyClass=="Co-safety"):
                tkMessageBox.showinfo( "status" , "The inout TA defines a property belonging to "+propertyClass+" class."   )
            else:
                tkMessageBox.showinfo( "status" , "The property defined by the input TA is neither Safety nor Co-safety."   )
   
        uppaalModel.set("No file chosen!!")
    ########################################
    ## Buttons on the GUI ##
    B1 = Tkinter.Button(window, text ="chooseFile", command = openFile)
    B1.place (x=130, y=35)
    B2 = Tkinter.Button(window, text ="CheckClass", command = checkClass, fg = "light blue",
         bg = "dark blue")
    B2.place (x=90, y=70)
    ########################################    
   
    window.mainloop()
    
#########################################################################################################################
#########################################################################################################################



