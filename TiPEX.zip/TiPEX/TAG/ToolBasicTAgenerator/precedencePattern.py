import sys
import os.path
import shutil
import pyuppaal
################################################################################################
###############################################################################################
cwd = os.path.dirname(os.path.realpath(__file__))
Base_property = cwd+"/baseData.xml"

## To generate TA belonging to precedence pattern ##
## Generated TA defines property of form 
###"A sequence of "n=complexity" "act1" actions enables action "act2" after a delay of at least "timeConstraint" time units".###    
def generateTA(complexity, act1, act2, timeConstraint):
    shutil.copy(Base_property, cwd+"/Example_Gen.xml")
    property = "Example_Gen.xml"
    # Current working directory
    projdir = os.path.normpath(os.path.join(os.path.dirname(__file__), '..'))
    # system path
    sys.path = [projdir] + sys.path

    Uppaal_Model = os.path.join(os.path.dirname(__file__), property)
    Parsed_NTA_Pyuppaal = pyuppaal.NTA.from_xml(open(Uppaal_Model))
    Property = Parsed_NTA_Pyuppaal.templates[0]
    
    Property.clocks=[]
    Property.chan=[]
    
    Property.add_Clock("x")
    Property.add_Chan(act1)
    Property.add_Chan(act2)
    
  
    currentLocation = Property.get_location_by_name("L0")
    initLocation =  Property.get_location_by_name("L0")
    #get the id of L0 in the run automaton
    locationIDcount = int((currentLocation.id)[-1])+1
    locationLableCount = 1
    locXpos = currentLocation.xpos
    locYpos = currentLocation.ypos
    
    ## Bad location####
    badLocation = pyuppaal.Location(name="NAcc", id ="NAcc", xpos = currentLocation.xpos+400 , ypos =currentLocation.ypos-300)
    t1 = pyuppaal.Transition(badLocation, badLocation, synchronisation = act1+"?")
    t2 = pyuppaal.Transition(badLocation, badLocation, synchronisation = act2+"?")
    Property.add_Location(badLocation)
    Property.add_Transition(t1)
    Property.add_Transition(t2)
        
    for x in range(0,complexity):
        newLocation = pyuppaal.Location(name="L"+str(locationLableCount), id ="id" + str(locationIDcount), xpos = currentLocation.xpos+100 , ypos =currentLocation.ypos)
        locationIDcount= locationIDcount+1
        locationLableCount = locationLableCount+1
                
        Property.add_Location(newLocation)
        t1 = pyuppaal.Transition(currentLocation, newLocation, synchronisation = act1+"?")
        t2 = pyuppaal.Transition(currentLocation, badLocation, synchronisation = act2+"?")
        currentLocation = newLocation
        Property.add_Transition(t1)
        Property.add_Transition(t2)
    
    t1 = pyuppaal.Transition(currentLocation, initLocation, guard="x>="+str(timeConstraint), synchronisation = act2+"?" )
    t2 = pyuppaal.Transition(currentLocation, currentLocation, synchronisation = act1+"?" )
    t3 = pyuppaal.Transition(currentLocation, badLocation, guard="x<"+str(timeConstraint), synchronisation = act2+"?" )
    Property.add_Transition(t1)
    Property.add_Transition(t2)
    Property.add_Transition(t3)
            
    pyuppaal.Template.to_xml(Property)
    f = open(Uppaal_Model, "r+")
    f.writelines(pyuppaal.NTA.to_xml(Parsed_NTA_Pyuppaal))
    f.close()

    print "TA is generated, and is written to file Example_Gen.xml" 
##################################################################################################################
